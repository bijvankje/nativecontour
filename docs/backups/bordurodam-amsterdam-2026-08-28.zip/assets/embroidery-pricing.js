document.addEventListener('DOMContentLoaded', function () {
  const form = document.querySelector('form[data-product-form]');
  if (!form) return;

  const mapEl = document.getElementById('embroidery-text-surcharge-map');
  let surchargeMap = {};
  if (mapEl) {
    try {
      surchargeMap = JSON.parse(mapEl.textContent);
    } catch (e) {
      console.error('Kon toeslag-data niet lezen', e);
    }
  }

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const submitButton = form.querySelector('button[type="submit"][name="add"]');
    if (submitButton) submitButton.disabled = true;

    try {
      const formData = new FormData(form);

      // Stap 1: hoofdproduct toevoegen aan winkelwagen
      const mainResponse = await fetch('/cart/add.js', {
        method: 'POST',
        body: formData
      });
      if (!mainResponse.ok) throw new Error('Kon product niet toevoegen aan winkelwagen');

      // Stap 2: check of er een tekstborduring is ingevuld
      const tekstInput = form.querySelector('input[name="properties[Tekst]"]');
      const tekstWaarde = tekstInput ? tekstInput.value.trim() : '';

      if (tekstWaarde) {
        const maatInput = form.querySelector('input[name="properties[Borduurmaat]"]');
        const gekozenMaat = maatInput ? maatInput.value : '';
        const surchargeVariantId = surchargeMap[gekozenMaat];

        if (surchargeVariantId) {
          await fetch('/cart/add.js', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: surchargeVariantId, quantity: 1 })
          });
        } else {
          console.warn('Geen toeslag gevonden voor borduurmaat:', gekozenMaat);
        }
      }

      // Stap 3: naar winkelwagen sturen
      window.location.href = '/cart';

    } catch (err) {
      console.error(err);
      alert('Er ging iets mis bij het toevoegen aan de winkelwagen. Probeer het opnieuw.');
      if (submitButton) submitButton.disabled = false;
    }
  });
});