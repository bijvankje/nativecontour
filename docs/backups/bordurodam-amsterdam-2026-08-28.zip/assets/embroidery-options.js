document.addEventListener('DOMContentLoaded', function () {
  const wrapper = document.querySelector('[data-embroidery-wrapper]');
  if (!wrapper) return;

  const fields = wrapper.querySelectorAll('[data-embroidery-field]');

  function showFieldFor(value) {
    fields.forEach(function (field) {
      const matches = field.getAttribute('data-embroidery-field') === value;
      field.hidden = !matches;

      const input = field.querySelector('[data-embroidery-input]');
      if (input) {
        input.required = matches;
        if (!matches) input.value = '';
      }
    });
  }

  const selectEl = document.querySelector('select[name="Borduring"], select[name*="option"][id*="Borduring"]');
  if (selectEl) {
    showFieldFor(selectEl.value);
    selectEl.addEventListener('change', function (e) {
      showFieldFor(e.target.value);
    });
  }

  const radios = document.querySelectorAll('input[type="radio"][name="Borduring"]');
  if (radios.length) {
    const checked = document.querySelector('input[type="radio"][name="Borduring"]:checked');
    if (checked) showFieldFor(checked.value);

    radios.forEach(function (radio) {
      radio.addEventListener('change', function (e) {
        if (e.target.checked) showFieldFor(e.target.value);
      });
    });
  }
});