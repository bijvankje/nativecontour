// Bordurodam theme JS
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-nav-toggle]');
  if (t) {
    const nav = document.querySelector('.site-nav');
    if (nav) nav.classList.toggle('is-open');
  }
});

// PDP configurator
(function initPDP(){
  const root = document.querySelector('[data-configurator]');
  if (!root) return;
  const form = root.closest('form');
  const swatches = root.querySelectorAll('[data-swatch]');
  const threadInput = root.querySelector('[name="properties[Garenkleur(en)]"]');
  const maxThreads = parseInt(root.dataset.maxThreads || '6', 10);
  const selected = new Set();

  swatches.forEach(sw => {
    sw.addEventListener('click', () => {
      const c = sw.dataset.swatch;
      if (selected.has(c)) { selected.delete(c); sw.classList.remove('is-active'); }
      else if (selected.size < maxThreads) { selected.add(c); sw.classList.add('is-active'); }
      if (threadInput) threadInput.value = Array.from(selected).join(', ');
    });
  });

  root.querySelectorAll('[data-chip-group]').forEach(group => {
    const input = root.querySelector(`[name="${group.dataset.for}"]`);
    group.querySelectorAll('[data-chip]').forEach(chip => {
      chip.addEventListener('click', () => {
        group.querySelectorAll('[data-chip]').forEach(c => c.classList.remove('is-active'));
        chip.classList.add('is-active');
        if (input) input.value = chip.dataset.chip;
      });
    });
  });

  // Gallery
  const main = document.querySelector('[data-pdp-main] img');
  document.querySelectorAll('[data-pdp-thumb]').forEach(th => {
    th.addEventListener('click', () => { if (main) main.src = th.dataset.pdpThumb; });
  });
})();
